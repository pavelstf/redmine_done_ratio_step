# Redmine Done Ratio Step

UI-only plugin for Redmine that changes the `% Done` / `Percent Complete` (`done_ratio`) options
from the default 10% increments to a configurable step (default **5%**).

## Compatibility
- Redmine **4.2+** (designed to work on 5.x as well)
- No DB migrations, no gem dependencies, no core view overrides.

## What it does
- Rebuilds `done_ratio` options in:
  - New/Edit issue forms
  - Bulk edit form (if present)
  - Issues list context menu (% Done submenu)

## Bugfixes
- **1.0.4**: Prevents broken context menu visualization when all issues are selected and Redmine exposes `% Done` links outside a nested submenu.
- **1.0.3**: Scopes preserved issue `done_ratio` values to the issue form select and clarifies the required deployment folder name.
- **1.0.2**: Also rebuilds `% Done` values in the issues list context menu to match the configured step.
- **1.0.1**: Preserves non-standard stored `done_ratio` values (e.g. 15%) on edit forms to prevent browser defaulting to 0%.

## Installation
1. Copy plugin folder into Redmine:
   - `redmine/plugins/redmine_done_ratio_step`
   - The folder name must be `redmine_done_ratio_step`, not `redmine_done_ratio_step_1.0.2` or another versioned directory name.
2. Restart Redmine app server (Passenger/Puma/etc.)
3. Configure:
   - **Administration → Plugins → Done Ratio Step (Percent Complete) → Configure**

## Rollback
- Disable the plugin, or remove the folder and restart.

## Notes
- This plugin changes **only the UI options**. Redmine continues storing `done_ratio` as an integer 0..100.
